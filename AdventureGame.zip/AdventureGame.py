import time
import random

chestLocation = random.randint(1, 2)
items = []


def print_pause(message, amount):
    print(message)
    time.sleep(amount)


def intro():
    print_pause("So here you are, you've heard of riches beyond imagination\n"
                "locked away in a chest somewhere in the abandoned haunted\n"
                "house on top of the hill.\n", 5)
    print_pause("Many have tried and failed due to all the ghosts and ghouls\n"
                "that lurk within. You decide to enter the house with only\n"
                "your flashlight and some courage.\n", 5)
    print_pause("After dusting off a few cobwebs and looking around you find\n"
                "yourself in the dark, cold foyer of the house.\n", 5)
    print_pause("The door slams behind you!", 2)
    print_pause("WHAM!\n", 1)
    return confirm_journey()


def get_input(options, question):
    while True:
        choice = input(question + "\n")
        for option in options:
            if(choice == option):
                return choice
        print_pause("I'm sorry I don't understand.", 2)


def quit_game():
    response = get_input(['1', '2'], "Enter 1 to play again or 2 to quit:")
    if(response == '1'):
        return True
    else:
        print("Thanks for playing")


def confirm_journey():
    print_pause("Are you sure you want to continue this spooky adventure?", 3)
    choice = get_input(['1', '2'], "Press 1 to continue or 2 to leave.")
    if(choice == '1'):
        print_pause("Ah, you are brave, but will this be a wise choice?", 3)
        return True
    else:
        print_pause("You return home with your life, but\n"
                    "you have lost the chance for treasure.\n"
                    "Maybe another brave soul will try.", 3)
        quit_game()
        return False


def spawn_ghost():
    ghost = random.randint(1, 2)
    if(ghost == 1):
        print_pause("You are looking around the room "
                    "and you get the chills.", 4)
        print_pause("All of a sudden a ghost appears and tries to attack!", 4)
        choice = get_input(['1', '2'], "Enter 1 to fight or 2 to run:")
        if(choice == '1'):
            print_pause("You shine your flashlight on the "
                        "ghost and the ghost fades away!", 4)
            print_pause("Startled but still alive you continue.", 3)
            return True
        else:
            print_pause("You try to run but the ghost catches you.", 3)
            print_pause("You lost, you have become a ghost!", 3)
            return False
    else:
        return True


def foyer():
    print_pause("In front of you are two sets of stairs.", 2)
    print_pause("One set of stairs leading to the attic", 2)
    print_pause("One leading to the basement", 2)
    choice = get_input(['1', '2'], "Please enter 1 to go up into the "
                       "attic or 2 to go down into the basement:")
    if(choice == '1'):
        return 'attic'
    else:
        return 'basement'


def attic():
    print_pause("You are now in the attic", 3)
    if(spawn_ghost() is False):
        return "Game Over"
    if(chestLocation == 1):
        if('key' in items):
            print_pause("You see the treasure chest hidden in the corner,\n"
                        "You open the chest and see diamonds,"
                        " gold and precious jewels.", 5)
            print_pause("Congrats! You've won and became the "
                        "richest person in the world!", 5)
            return "Game Over"
        else:
            print_pause("You can see the treasure chest "
                        "hidden in the corner,\nbut it requires "
                        "a key. You return to the foyer.", 5)
            return 'foyer'
    else:
        if('key' in items):
            print_pause("All you see is dust and webs. "
                        "You decide to go back.", 3)
            return 'foyer'
        else:
            print_pause("You see a dusty old key on the floor.", 3)
            print_pause("You put it in your pocket and "
                        "head back to the foyer.", 3)
            items.append('key')
            return 'foyer'


def basement():
    print_pause("You are now in the basement", 3)
    if(spawn_ghost() is False):
        return "Game Over"
    if(chestLocation == 2):
        if('key' in items):
            print_pause("You see the treasure chest hidden in the corner,\n"
                        "You open the chest and see diamonds,"
                        " gold and precious jewels.", 5)
            print_pause("Congrats! You've won and became the "
                        "richest person in the world!", 5)
            return "Game Over"
        else:
            print_pause("You can see the treasure chest "
                        "hidden in the corner,\nbut it requires "
                        "a key. You return to the foyer.", 5)
            return 'foyer'
    else:
        if('key' in items):
            print_pause("All you see is dust and webs. "
                        "You decide to go back.", 3)
            return 'foyer'
        else:
            print_pause("You see a dusty old key on the floor.", 3)
            print_pause("You put it in your pocket and "
                        "head back to the foyer.", 3)
            items.append('key')
            return 'foyer'


def enterRoom(room):
    if(room == "foyer"):
        enterRoom(foyer())
    elif(room == "attic"):
        enterRoom(attic())
    elif(room == "basement"):
        enterRoom(basement())


def start_game():
    if(intro()):
        enterRoom('foyer')
        if(quit_game()):
            start_game()


start_game()
